import pygame
import random
import math
from GUI_v1 import *
from Support import *
from Colors import *

"""
Snake_v08
"""
# Data
crash_sound = load_sound('sounds_and_music/crash.wav')
eatself_sound = load_sound('sounds_and_music/eatself.wav')
eat_sound = load_sound('sounds_and_music/apple_eat.wav')
boom_sound = load_sound('sounds_and_music/boom.wav')
apple_img = load_image('pictures/apple.png')
bomb_img = load_image('pictures/bomb.png')
boom_img = load_image('pictures/boom.jpg')
barrier_img = load_image('pictures/box.png')
game_over_img = load_image('pictures/game_over.jpg')
back_ground_snake_img = load_image('pictures/snake.png', -1)
head = load_image('pictures/snake_head.png', WHITE)
unit = load_image('pictures/snake_unit.png', WHITE)
turn = load_image('pictures/snake_turn.png', WHITE)
tail = load_image('pictures/snake_tail.png', WHITE)

# Setup
pygame.init()
w, h = 1200, 960
screen = pygame.display.set_mode((w, h))
pygame.display.set_caption('Snake')
clock = pygame.time.Clock()
cell_size = max((w, h)) // 25


class Apple:
    def __init__(self):
        self.image = apple_img
        self.born_time = pygame.time.get_ticks()

    def is_alive(self):  # Returns True if dead, else - False
        if pygame.time.get_ticks() - self.born_time > 10000:
            game.create_item(Apple)
            return False
        return True


class Bomb:
    def __init__(self):
        self.image = bomb_img
        self.born_time = pygame.time.get_ticks()

    def is_alive(self):
        if pygame.time.get_ticks() - self.born_time > 6000:
            return False
        return True


class Barrier:
    def __init__(self, image):
        self.image = image


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.default_color = None
        self.left = None
        self.top = None
        self.cell_size = None
        self.board = None

    def set_view(self, left, top, cell_size, default_color):
        self.left = left
        self.top = top
        self.cell_size = cell_size
        self.default_color = default_color
        self.board = [[None for _ in range(self.width)] for _ in range(self.height)]

    def clear_cell(self, x, y):
        self.board[y][x] = None

    def update(self):
        index = game.snake.head_index
        head_pos = game.snake.units[index][0]
        next_head_pos = ((head_pos[0] + game.snake.x_dir) % self.width, (head_pos[1] + game.snake.y_dir) % self.height)
        if next_head_pos in map(lambda x: x[0], game.snake.units):
            if game.sounds == 'ON':
                eatself_sound.play()
            game.lose()
            return

        for y in range(self.height):
            for x in range(self.width):
                thing = self.board[y][x]
                name = type(thing)
                if hasattr(thing, 'is_alive') and not thing.is_alive():
                    self.clear_cell(x, y)
                if next_head_pos == (x, y):
                    if name == Apple:
                        self.clear_cell(x, y)
                        img_index = (game.snake.head_index + 1) % game.snake.len + 6
                        game.snake.units.append([(x, y), img_index])
                        game.snake.len += 1
                        if game.sounds == 'ON':
                            eat_sound.play()
                        game.score += 1
                        game.fps += 0.5
                        game.create_item(Apple)
                        if game.score % 5 == 0 and game.score > 0:
                            pygame.time.set_timer(change_color, 2000)
                        else:
                            pygame.time.set_timer(change_color, 0)
                    elif name == Barrier:
                        if game.sounds == 'ON':
                            crash_sound.play()
                        game.lose()
                if head_pos == (x, y):
                    if name == Bomb:
                        if game.sounds == 'ON':
                            boom_sound.play()
                        screen.blit(boom_img, (0, 0))
                        game.lose()
        game.snake.move()

    def render(self):
        side = self.cell_size
        for y in range(self.height):
            for x in range(self.width):
                pos = (self.left + x * side, self.top + y * side)
                thing = self.board[y][x]
                l = list(map(lambda x: x[0], game.snake.units))
                index = l.index((x, y)) if (x, y) in l else -1
                if hasattr(thing, 'image'):
                    screen.blit(thing.image, pos)
                elif index != -1:
                    img_index = game.snake.units[index][1]
                    img = game.snake_imgs[img_index]
                    screen.blit(img, pos)


class Snake:
    def __init__(self, units, direction):
        # Looped list with pointer
        self.units = units.copy()
        self.head_index = len(units) - 1
        self.direction = direction
        self.x_dir, self.y_dir = direction
        self.len = self.head_index + 1
        self.head_img_index = 6

    def move(self):
        x, y = self.units[self.head_index][0]
        if 6 <= self.units[self.head_index][1] <= 9:
            self.units[self.head_index][1] = 4 if self.units[self.head_index][1] % 2 == 0 else 5
        new_pos = ((x + self.x_dir) % game.board.width, (y + self.y_dir) % game.board.height)
        self.head_index = (self.head_index + 1) % self.len
        unit_index = (self.head_index + 2) % self.len
        x, y = self.units[unit_index][0]
        tail_index = (self.head_index + 1) % self.len
        tail_x, tail_y = self.units[tail_index][0]
        if x != tail_x:
            self.units[tail_index][1] = 10 if x > tail_x or x == game.board.width else 12
        elif y != tail_y:
            self.units[tail_index][1] = 13 if y > tail_y or y == game.board.height else 11
        self.units[self.head_index] = [new_pos, self.head_img_index]

    def change_direction(self, direction):
        x, y = self.units[self.head_index][0]
        n_head_pos = (x + direction[0], y + direction[1])
        if n_head_pos not in map(lambda x: x[0], self.units):
            x_dir, y_dir = direction
            if direction != self.direction:
                if abs(x_dir) > 0:
                    self.head_img_index = 8 if x_dir < 0 else 6
                else:
                    self.head_img_index = 6 + (3 if y_dir == 1 else 1)
                if (self.x_dir == 1 and y_dir == 1) or (self.y_dir == -1 and x_dir == -1):
                    self.units[self.head_index][1] = 2
                elif (self.y_dir == -1 and x_dir == 1) or (self.x_dir == -1 and y_dir == 1):
                    self.units[self.head_index][1] = 3
                elif (self.x_dir == 1 and y_dir == -1) or (self.y_dir == 1 and x_dir == -1):
                    self.units[self.head_index][1] = 1
                else:
                    self.units[self.head_index][1] = 0
                self.direction = direction
                self.x_dir, self.y_dir = direction


class SnakeGame:
    def __init__(self):
        # Functions for buttons

        # Action for "Back" button.
        def __back():
            if self.gui.active_page in ('Settings', 'Scoreboard', 'Controls'):
                self.gui.open_page('Main_menu')

        # Action for "Sounds" button. It turns on or turns off sounds
        def __sounds():
            if self.gui.pages['Settings'][2].text == 'Sounds: ON':
                self.gui.pages['Settings'][2].change_text('Sounds: OFF')
                self.sounds = 'OFF'
            else:
                self.gui.pages['Settings'][2].change_text('Sounds: ON')
                self.sounds = 'ON'

        # Action for "Complexity" button. It switches complexity
        def __complexity():
            if self.complexity == 'Easy':
                self.complexity = 'Medium'
            elif self.complexity == 'Medium':
                self.complexity = 'Hard'
            else:
                self.complexity = 'Easy'
            self.gui.pages['Settings'][0].change_text('Complexity: ' + self.complexity)

        # Action for "Barriers" button. It switches barriers type
        def __barriers():
            index = barriers_types.index(self.barriers_type) + 1
            if index == len(barriers_types):
                index = 0
            self.barriers_type = barriers_types[index]
            self.gui.pages['Settings'][1].change_text('Barriers: ' + self.barriers_type)

        # Clock
        self.clock = pygame.time.Clock()

        # Loading settings
        if os.path.exists('data/settings.txt'):
            with open('data/settings.txt') as file:
                data = map(lambda x: x.split(':'), file.read().split('\n'))
            for name, value in data:
                if 'color' in name:
                    value = tuple(map(int, value[1:-1].split(', ')))
                setattr(SnakeGame, name, value)
        else:
            self.complexity = 'Medium'
            self.barriers_type = 'Room'
            self.sounds = 'ON'

        # Gui setup
        self.gui = GUI()
        x = w / 3
        size = (w / 3, 0.1 * h)  # Button width and height
        color = ((50, 50, 50), BLACK, YELLOW)  # Text color, background color
        menu_elements = [
            Button((x, 0.35 * h, *size), 'Play', 90, *color, action=self.__play),
            Button((x, 0.45 * h, *size), 'Settings', 90, *color, action=lambda: self.gui.open_page('Settings')),
            Button((x, 0.55 * h, *size), 'Scoreboard', 90, *color, action=lambda: self.gui.open_page('Scoreboard')),
            Button((x, 0.65 * h, *size), 'Controls', 90, *color, action=lambda: self.gui.open_page('Controls')),
            Button((x, 0.75 * h, *size), 'Quit', 90, *color, action=self._quit)]
        self.gui.add_page('Main_menu', menu_elements)

        x = 0.2 * w
        size = (0.6 * w, size[1])
        settings_elements = [
            Button((x, 0.35 * h, *size), 'Complexity: ' + self.complexity, 90, *color, action=__complexity),
            Button((x, 0.45 * h, *size), 'Barriers: ' + self.barriers_type, 90, *color, action=__barriers),
            Button((x, 0.55 * h, *size), 'Sounds: ' + self.sounds, 90, *color, action=__sounds),
            Button((x, 0.65 * h, *size), 'Back', 90, *color, action=__back)]
        setattr(settings_elements[3], 'index', 2)
        self.gui.add_page('Settings', settings_elements)
        if os.path.exists('data/scoreboard.txt'):
            with open('data/scoreboard.txt') as file:
                scores = file.read()
            if scores:
                self.score_list = list(map(int, scores.split(', ')))
                text = '\n'.join(map(lambda x: '%d.  %d' % (x[0] + 1, x[1]), enumerate(self.score_list)))
            else:
                self.score_list = []
                text = ''
        else:
            self.score_list = []

        scoreboard_elements = [
            Label((0.44 * w, 0.34 * h, 0.12 * w, 0.5 * h), text, 45, BLACK, DARK_YELLOW),
            Button((0.44 * w, 0.86 * h, 0.12 * w, 0.07 * h), 'Back', 70, *color,
                   action=__back)]
        self.gui.add_page('Scoreboard', scoreboard_elements)

        with open('data/controls.txt') as file:
            text = file.read()
        controls_elements = [
            Label((0.33 * w, 0.4 * h, 0.35 * w, 0.2 * h), text, 60, BLACK, None),
            Button((0.33 * w, 0.65 * h, 0.35 * w, 0.08 * h), 'Back', 70, *color, action=__back)]
        self.gui.add_page('Controls', controls_elements)

        # Score and game speed
        self.fps = complexity_levels[self.complexity]
        self.score = 0
        self.gui.open_page('Main_menu')
        self.paused = True
        self.lost = False
        self.first_game = True
        self.pause_fps = 50

    # Action for "Play" button. It starts game
    def __play(self):
        if self.first_game:
            self.first_game = False

        # Making default images
        self.snake_imgs = [turn, pygame.transform.rotate(turn, 90), pygame.transform.rotate(turn, 180),
                           pygame.transform.rotate(turn, 270), unit, pygame.transform.rotate(unit, 90), head,
                           pygame.transform.rotate(head, 90), pygame.transform.rotate(head, 180),
                           pygame.transform.rotate(head, 270), tail, pygame.transform.rotate(tail, 90),
                           pygame.transform.rotate(tail, 180),
                           pygame.transform.rotate(tail, 270)]

        # Stating over
        self.fps = complexity_levels[self.complexity]
        self.score = 0
        self.paused = False
        self.lost = False
        pygame.time.set_timer(change_color, 0)
        self.gui.close()
        # Board setup
        self.board = Board(w // cell_size, h // cell_size)
        self.board.set_view(0, 0, cell_size, GREY)
        # Snake setup
        self.snake = Snake([[(2, 2), 10], [(3, 2), 4], [(4, 2), 6]], (1, 0))
        self.create_item(Bomb)
        pygame.time.set_timer(create_bomb, 5000)
        if self.barriers_type == 'Random':
            # Create random barriers
            x, y = self.snake.units[self.snake.head_index][0]
            snake_space = list(map(lambda x: x[0], self.snake.units)) + get_neighbours(x, y, self.board.width,
                                                                                       self.board.height) + [(x + 2, y),
                                                                                                             (x + 3, y)]
            x, y = random.randrange(self.board.width), random.randrange(self.board.height)
            direction = [1, 0]
            for i in range(120):
                new_x, new_y = (x + direction[0]) % self.board.width, (y + direction[1]) % self.board.height
                if (x, y) not in snake_space:
                    self.board.board[y][x] = Barrier(barrier_img)
                if random.randrange(8) == 0 or type(self.board.board[new_y][new_x]) == Barrier:
                    if abs(direction[0]) == 1:
                        test_y1 = (y + 1) % self.board.height
                        test_y2 = (y - 1) % self.board.height
                        for j in range(-1, 2):
                            test_x = (x + j) % self.board.width
                            if type(self.board.board[test_y1][test_x]) == Barrier:
                                self.board.clear_cell(test_x, test_y1)
                            if type(self.board.board[test_y2][test_x]) == Barrier:
                                self.board.clear_cell(test_x, test_y2)
                        direction[0] = 0
                        direction[1] = random.choice([-1, 1])
                    else:
                        test_x1 = (x + 1) % self.board.width
                        test_x2 = (x - 1) % self.board.width
                        for j in range(-1, 2):
                            test_y = (y + j) % self.board.height
                            if type(self.board.board[test_y][test_x1]) == Barrier:
                                self.board.clear_cell(test_x1, test_y)
                            if type(self.board.board[test_y][test_x2]) == Barrier:
                                self.board.clear_cell(test_x2, test_y)
                        direction[1] = 0
                        direction[0] = random.choice([-1, 1])
                x = new_x
                y = new_y
            for x in range(self.board.width):
                for y in range(self.board.height):
                    if len([(x, y) for x, y in get_neighbours(x, y, self.board.width, self.board.height) if
                            type(self.board.board[y][x]) == Barrier]) == 0:
                        self.board.clear_cell(x, y)
        elif self.barriers_type == 'Room':
            # Create "Room" like in classic snake game
            for i in range(1, self.board.height - 1):
                self.board.board[i][0] = Barrier(barrier_img)
                self.board.board[i][-1] = Barrier(barrier_img)
            self.board.board[0] = list(map(lambda x: Barrier(barrier_img), self.board.board[0]))
            self.board.board[-1] = list(map(lambda x: Barrier(barrier_img), self.board.board[-1]))
        # Create first food
        self.create_item(Apple)

    # Action for "Quit" button. It saves settings, scoreboard and quits
    def _quit(self):
        with open('data/settings.txt', mode='w') as file:
            file.write('\n'.join(['complexity:' + self.complexity,
                                  'barriers_type:' + self.barriers_type,
                                  'sounds:' + self.sounds]))
        with open('data/scoreboard.txt', mode='w') as file:
            file.write(', '.join(map(str, self.score_list)))
        pygame.quit()
        exit()

    # Catches events
    def get_event(self, event):
        # Third statement is used to confirm it's not first game
        if event.type == pygame.QUIT:
            game._quit()
        elif event.type == pygame.KEYDOWN and not self.lost:
            key = event.key
            if key == pygame.K_w:
                self.snake.change_direction((0, -1))
            if key == pygame.K_s:
                self.snake.change_direction((0, 1))
            if key == pygame.K_a:
                self.snake.change_direction((-1, 0))
            if key == pygame.K_d:
                self.snake.change_direction((1, 0))
            if key == pygame.K_ESCAPE and not self.first_game:
                self.paused = not self.paused
                if self.gui.is_active():
                    self.gui.close()
                else:
                    self.gui.open_page('Main_menu')
        elif event.type == change_color and not self.paused:
            change = random.randrange(255)
            for i in range(len(self.snake_imgs)):
                img = change_image(self.snake_imgs[i], change)
                colorkey = img.get_at((0, 47))
                img.set_colorkey(colorkey)
                self.snake_imgs[i] = img
            new_barrier_img = change_image(barrier_img, random.randrange(255))
            for x in range(self.board.width):
                for y in range(self.board.height):
                    thing = self.board.board[y][x]
                    if type(thing) == Barrier:
                        thing.image = new_barrier_img
        elif event.type == create_bomb:
            for i in range(random.randrange(10)):
                self.create_item(Bomb)
        self.gui.get_event(event)

    def render(self):
        if self.paused:
            screen.fill(DARK_YELLOW)
            screen.blit(back_ground_snake_img, (380, 0))
        else:
            screen.fill(GREY)
            if not self.first_game:
                self.board.render()
            # Score sign
            font = pygame.font.Font(None, 50)
            text = font.render('Score: %d' % self.score, 1, WHITE)
            screen.blit(text, ((w - text.get_width()) / 2, 20))
        # GUI
        self.gui.render(screen)

    def lose(self):
        pygame.display.flip()
        pygame.time.wait(2000)

        # Add score to scoreboard if it's the biggest one
        if not self.score_list or self.score > self.score_list[0]:
            if len(self.score_list) < 12:
                self.score_list.insert(0, self.score)
                text = '\n'.join(map(lambda x: '%d. %d' % (x[0] + 1, x[1]), enumerate(self.score_list)))
                self.gui.pages['Scoreboard'][0].change_text(text)
            else:
                self.score_list = [self.score] + self.score_list[:-1]
        self.lost = True
        self.paused = True
        self.gui.open_page('Main_menu')
        screen.blit(game_over_img, (0, 0))
        pygame.display.flip()
        pygame.time.wait(2000)

    def play(self):
        if self.paused:
            self.gui.update()
            self.clock.tick(self.pause_fps)
        else:
            self.board.update()
            self.clock.tick(self.fps)

    def create_item(self, item_class, *args):
        x, y = self.snake.units[self.snake.head_index][0]
        snake_space = list(map(lambda x: x[0], self.snake.units)) + get_neighbours(x, y, self.board.width,
                                                                                   self.board.height) + [(x + 2, y),
                                                                                                         (x + 3, y)]
        while (x, y) in snake_space or self.board.board[y][x] is not None:
            x, y = random.randint(1, self.board.width - 2), random.randint(1, self.board.height - 2)
        self.board.board[y][x] = item_class(*args)


game = SnakeGame()

while True:
    for event in pygame.event.get():
        game.get_event(event)
    game.play()
    game.render()
    pygame.display.flip()
