import pygame
import os


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
        if colorkey is not None:
            if colorkey == -1:
                colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
        return image
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)


def load_sound(name):
    fullname = os.path.join('data', name)
    try:
        sound = pygame.mixer.Sound(fullname)
        return sound
    except pygame.error as message:
        print('Cannot load sound:', name)
        raise SystemExit(message)


def get_neighbours(x, y, x_lim, y_lim):
    neighbours = []
    for i in range(-1, 2):
        x1 = (x + i) % x_lim
        neighbours.append((x1, (y + 1) % y_lim))
        neighbours.append((x1, (y - 1) % y_lim))
    neighbours.append(((x + 1) % x_lim, y))
    neighbours.append(((x - 1) % x_lim, y))
    return neighbours


def change_image(image, value):
    pixels = pygame.surfarray.array2d(image)
    pixels[:,:] += value
    return pygame.surfarray.make_surface(pixels)


# Const
snake_colors = [['WHITE', (255, 255, 255)], ['BLACK', (0, 0, 0)], ['GREEN', (0, 255, 0)], ['GREY', (100, 100, 100)],
                ['YELLOW', (240, 240, 0)], ['RED', (240, 0, 0)], ['PURPLE', (128, 0, 128)]]
complexity_levels = {'Easy': 1, 'Medium': 3, 'Hard': 5}
barriers_types = ['Room', 'Random', 'None']

change_color = 31
create_bomb = 30
boom_event = 0
